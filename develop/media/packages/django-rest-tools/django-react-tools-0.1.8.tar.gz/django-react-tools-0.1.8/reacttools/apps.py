from django.apps import AppConfig


class ReacttoolsConfig(AppConfig):
    name = 'reacttools'
